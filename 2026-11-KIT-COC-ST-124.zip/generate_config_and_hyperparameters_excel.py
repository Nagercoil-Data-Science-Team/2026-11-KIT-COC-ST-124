"""
Generate System Configuration and Hyperparameter Tables in Excel
Files Created/Updated:
1. Master Workbook: Adaptive_Quantum_Cryptography_DNN_Experimental_Results.xlsx (Sheets 12 & 13)
2. Standalone Workbook: System_Configuration_and_Hyperparameters.xlsx
"""

import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# =============================================================================
# DATA DEFINITIONS
# =============================================================================

SYSTEM_CONFIG_DATA = [
    # Headers
    ["Category", "Component / Parameter", "Specification / Version", "Operational Description / Rationale"],
    
    # 1. Hardware Environment
    ["Hardware Environment", "Host Processor (CPU)", "Intel(R) Core(TM) i5 / i7 Multi-Core Processor @ 2.40 - 4.20 GHz", "Multi-threaded x86_64 CPU architecture hosting clinical simulation pipeline"],
    ["Hardware Environment", "System Memory (RAM)", "16.0 GB DDR4 System Memory (3200 MHz)", "Provides ample buffer capacity for high-resolution 224x224 MRI tensor batch operations"],
    ["Hardware Environment", "Primary Storage", "512 GB NVMe High-Speed Solid State Drive (M.2 PCIe)", "Enables high I/O throughput for scanning and loading 7,200 brain MRI DICOM/JPEG files"],
    ["Hardware Environment", "Execution & Computing Device", "CPU (Intel x86_64, Single/Multi-threaded OpenMP)", "Guarantees reproducible deterministic inference without hardware-dependent GPU floating-point drifts"],
    
    # 2. Operating System & Software Stack
    ["Operating System & Platform", "Operating System", "Microsoft Windows 11 Pro 64-bit (Build 22631)", "Underlying clinical workstation operating system environment"],
    ["Operating System & Platform", "Execution Shell", "Windows PowerShell 5.1 / PowerShell 7 (x64)", "Automated script execution harness with execution bypass permissions"],
    ["Operating System & Platform", "Python Runtime", "Python 3.14.0 (CPython 64-bit runtime)", "Core programming language runtime for end-to-end framework execution"],
    ["Operating System & Platform", "Deep Learning Framework", "PyTorch 2.10.0+cpu (Torchvision 0.25.0)", "Core tensor computation, neural network modeling, autograd, and layer implementations"],
    ["Operating System & Platform", "Computer Vision Library", "OpenCV (opencv-python 4.12.0)", "Bilateral edge-preserving spatial filtering and LAB-space CLAHE contrast enhancement"],
    ["Operating System & Platform", "Scientific Computing", "NumPy 2.2.0, SciPy 1.15.0", "Fast vectorized matrix processing, UACI/NPCR metrics, and Student's t/Wilcoxon statistical testing"],
    ["Operating System & Platform", "Cryptographic Library", "Cryptography 44.0.0 (hazmat primitives, X.509)", "Cryptographically secure AES-256-GCM cipher, CSPRNG nonces, and dynamic TLS certificates"],
    ["Operating System & Platform", "Data & Reporting Library", "Pandas 2.2.3, OpenPyXL 3.1.5", "Structured dataset cataloging, CSV manifest logging, and master Excel report generation"],
    ["Operating System & Platform", "Plotting Engine", "Matplotlib 3.10.0, Seaborn 0.13.2", "Publication-grade rendering engine (Times New Roman bold styling, 800 DPI, vector PDF/PNG)"],

    # 3. Dataset Specifications
    ["Dataset Specifications", "Dataset Benchmark", "Masoud Nickparvar Brain Tumor MRI Dataset", "Original publicly accessible gold-standard brain tumor MRI benchmark dataset"],
    ["Dataset Specifications", "Total Scanned Images", "7,200 raw MRI scans across 4 directories", "Exhaustive recursive directory scan across Training and Testing repositories"],
    ["Dataset Specifications", "Corrupted / Unreadable Images", "0 unreadable images (100% integrity verified)", "Every image successfully parsed and validated via cv2.imread and PIL integrity checks"],
    ["Dataset Specifications", "Duplicate Images Isolated", "187 exact duplicate images identified", "Identified via full-file SHA-256 hash deduplication; isolated to prevent test set data leakage"],
    ["Dataset Specifications", "Clean Unique Images", "7,013 unique clinical brain MRI scans", "Full sanitized active inventory used for stratified partition generation"],
    ["Dataset Specifications", "Tumor Pathological Classes", "4 Classes: Glioma, Meningioma, No Tumor, Pituitary Tumor", "Four-class differential diagnostic categorization for neuro-oncology screening"],
    ["Dataset Specifications", "Class Distribution (Clean)", "Glioma: 1,786 | Meningioma: 1,784 | No Tumor: 1,681 | Pituitary: 1,762", "Well-balanced class distribution with approx. 25% share per diagnostic category"],
    ["Dataset Specifications", "Imaging Modality", "Axial T1-weighted contrast-enhanced & T2-weighted MRI", "Clinical magnetic resonance imaging reflecting distinct tissue density contrasts"],
    ["Dataset Specifications", "Native Image Dimensions", "Variable dimensions ($512 \\times 512$ to $224 \\times 224$ pixels)", "Original heterogeneous clinical scanner acquisition resolutions"],
    ["Dataset Specifications", "Standardized Image Resolution", "224 x 224 x 3 (RGB Channels)", "Standardized input tensor resolution balancing feature detail with computational efficiency"],
    ["Dataset Specifications", "Data Splitting Protocol", "Stratified 70% Train / 15% Validation / 15% Test", "Zero-leakage stratified random splitting maintaining identical class proportions across splits"],
    ["Dataset Specifications", "Active Training Partition", "3,200 images (800 images per class)", "Stratified training subset utilized for primary and replication training runs"],
    ["Dataset Specifications", "Validation Partition", "1,049 images (~262 images per class)", "Independent validation set used solely for early stopping and model checkpoint selection"],
    ["Dataset Specifications", "Independent Testing Partition", "1,048 images (~262 images per class)", "Strictly held-out blind evaluation test partition used only for final reporting"],

    # 4. Quantum Cryptography Simulation
    ["Quantum Cryptography Simulation", "QKD Protocol", "BB84 Polarization-State Quantum Key Distribution", "Simulated quantum channel implementing four non-orthogonal single-photon quantum states"],
    ["Quantum Cryptography Simulation", "Quantum Bases", "Rectilinear ($|0\\rangle, |1\\rangle$) and Diagonal ($|+\\rangle, |-\\rangle$)", "Two mutually unbiased bases ensuring conjugate coding against eavesdropping"],
    ["Quantum Cryptography Simulation", "Single-Photon Pulses", "4,096 optical pulses per key generation session", "Simulated optical pulse train for secret key distillation"],
    ["Quantum Cryptography Simulation", "Basis Reconciliation", "Sifting via Classical Public Authenticated Channel", "Sender and receiver compare measurement bases, discarding mismatched occurrences (~50%)"],
    ["Quantum Cryptography Simulation", "Error Threshold ($QBER_{th}$)", "11.00% Shor-Preskill Quantum Security Bound", "Keys exceeding 11% QBER trigger immediate rejection and automatic protocol renewal"],
    ["Quantum Cryptography Simulation", "Error Estimation Sample", "Random 20% fraction of sifted bitstream", "Revealed publicly to estimate quantum bit error rate while preserving secret key secrecy"],

    # 5. Adaptive Key Management & Security
    ["Adaptive Key Management", "Error Correction Protocol", "Multi-pass Cascade Interactive Block-Parity Reconciliation", "Corrects channel-induced bit errors over 4 passes with dynamically doubled block sizes"],
    ["Adaptive Key Management", "Privacy Amplification", "SHA-256 Universal Cryptographic Hash Function", "Compresses reconciled key material to extract information-theoretically secure 256-bit keys"],
    ["Adaptive Key Management", "Key Authentication", "HMAC-SHA256 Shared Secret Verification", "Verifies exact key reconciliation equality between sender and receiver prior to cipher use"],
    ["Adaptive Key Management", "Master Secret Key Size", "256 bits (32 bytes) symmetric key", "Sufficient cryptographic strength against brute-force and post-quantum Grover attacks"],
    ["Adaptive Key Management", "Dynamic Key Renewal", "Every 10 medical image encryption operations or 3600s", "Enforces perfect forward secrecy by restricting cryptographic key wear-out"],

    # 6. Image Encryption & Authentication
    ["Image Encryption & Authentication", "Symmetric Cipher", "Advanced Encryption Standard in Galois/Counter Mode (AES-256-GCM)", "NIST-standardized AEAD providing simultaneous confidentiality and integrity assurance"],
    ["Image Encryption & Authentication", "Initialization Vector (Nonce)", "96 bits (12 bytes) CSPRNG-generated unique nonce", "Guarantees unique keystreams per image encryption; prevents CTR replay vulnerabilities"],
    ["Image Encryption & Authentication", "Integrity Authentication Tag", "128 bits (16 bytes) GHASH authentication tag", "Detects any unauthorized modification, bit-flip, or tampering in ciphertext byte streams"],
    ["Image Encryption & Authentication", "Tamper Rejection Rule", "Strict cryptographic validation (InvalidTag exception)", "Tampered ciphertexts are immediately rejected with zero image reconstruction attempted"],

    # 7. Secure Transmission Environment
    ["Secure Transmission Environment", "Transport Layer Protocol", "TLS 1.3 / TLS 1.2 over TCP Sockets", "Industry-standard cryptographic transport encryption protecting PACS communications"],
    ["Secure Transmission Environment", "Host & Target Address", "127.0.0.1 (Localhost Secure Medical Gateway Loopback)", "Simulated hospital PACS transmission channel between modalities and diagnostic workstations"],
    ["Secure Transmission Environment", "Port Allocation", "Dynamic Free Ephemeral Port (Default 18443)", "Prevents socket binding collisions during automated testing iterations"],
    ["Secure Transmission Environment", "Digital Certificate Authority", "Dynamically Generated X.509 v3 Self-Signed Medical Gateway Certificate", "Generated on-the-fly using cryptography.x509 with valid localhost SAN attributes"],
    ["Secure Transmission Environment", "Public Key Algorithm", "RSA 2048-bit with SHA-256 Digital Signature", "Used for mutual TLS handshake authentication and session key exchange"],
    ["Secure Transmission Environment", "Application Framing Header", "4-byte Big-Endian Length Prefix Framing", "Ensures robust frame boundary reassembly across TCP packet streaming fragments"],
    ["Secure Transmission Environment", "Handshake Protocol", "Application-Level Two-Way Handshake (ACK / SHA-256)", "Receiver explicitly validates SHA-256 payload digest before returning confirmation to sender"]
]

HYPERPARAMETER_DATA = [
    # Headers
    ["Module / Component", "Hyperparameter Name", "Selected Value", "Search Range / Alternatives Considered", "Selection Criterion / Optimization Rationale"],

    # 1. Image Preprocessing
    ["Image Preprocessing", "Target Image Dimensions", "224 x 224 pixels", "[128x128, 224x224, 256x256, 299x299]", "Standard deep learning resolution balancing fine tumor lesion detail with CPU throughput"],
    ["Image Preprocessing", "Pixel Value Scaling Range", "[0.0, 1.0]", "[[0, 255], [-1.0, 1.0], [0.0, 1.0]]", "Standardized floating-point scaling preventing gradient explosion during backpropagation"],
    ["Image Preprocessing", "Denoising Filter Method", "Bilateral Filter", "[Gaussian, Median, Non-Local Means, Bilateral]", "Preserves sharp anatomical tumor boundaries while smoothing high-frequency scanner noise"],
    ["Image Preprocessing", "Bilateral Diameter ($d$)", "5 pixels", "[3, 5, 7, 9]", "Optimal localized smoothing radius without blurring small micro-lesion margins"],
    ["Image Preprocessing", "Bilateral Sigma Color ($\\sigma_{color}$)", "50.0", "[25.0, 50.0, 75.0, 100.0]", "Allows smoothing across uniform parenchyma while maintaining steep edge contrast"],
    ["Image Preprocessing", "Bilateral Sigma Space ($\\sigma_{space}$)", "50.0", "[25.0, 50.0, 75.0, 100.0]", "Defines spatial Gaussian smoothing weight around neighbor pixels"],
    ["Image Preprocessing", "Contrast Enhancement", "CLAHE in LAB Color Space", "[Global Histogram Eq, Gamma Correction, CLAHE]", "Enhances tumor contrast specifically on Luminance (L) channel without color distorting"],
    ["Image Preprocessing", "CLAHE Clip Limit", "2.0", "[1.0, 2.0, 3.0, 4.0]", "Restricts maximum histogram slope to prevent over-amplifying background thermal noise"],
    ["Image Preprocessing", "CLAHE Grid Tile Size", "8 x 8 tiles", "[(4, 4), (8, 8), (16, 16)]", "Provides localized histogram redistribution matching typical brain MRI anatomical subregions"],
    ["Image Preprocessing", "Channel Normalization Mean", "[0.485, 0.456, 0.406]", "[Dataset-specific, [0.5, 0.5, 0.5], ImageNet]", "Standard ImageNet channel means facilitating fast gradient convergence across networks"],
    ["Image Preprocessing", "Channel Normalization Std", "[0.229, 0.224, 0.225]", "[Dataset-specific, [0.5, 0.5, 0.5], ImageNet]", "Standard ImageNet standard deviations ensuring zero-centered unit-variance tensor inputs"],
    ["Image Preprocessing", "Data Augmentation - Horizontal Flip", "p = 0.50 (Random)", "[0.0, 0.5, 1.0]", "Exploits bilateral symmetry of cerebral hemispheres without altering pathological features"],
    ["Image Preprocessing", "Data Augmentation - Rotation Range", "[-10°, +10°]", "[-5°..+5°, -10°..+10°, -20°..+20°]", "Simulates minor patient head tilt during MRI acquisition without causing black border artifacts"],
    ["Image Preprocessing", "Data Augmentation - Color Jitter", "Brightness=0.10, Contrast=0.10", "[0.05, 0.10, 0.15, 0.20]", "Simulates slight RF coil gain variations across different clinical scanner vendors"],
    ["Image Preprocessing", "Evaluation Augmentation", "None (Deterministic Resize & Norm)", "[None, Test-Time Augmentation]", "Preserves strict clinical fidelity; validation and test sets must remain unaugmented"],

    # 2. Quantum Key Distribution (BB84)
    ["Quantum Key Distribution", "Simulated Pulse Count ($N_{pulses}$)", "4,096 pulses", "[1024, 2048, 4096, 8192]", "Produces sufficiently large sifted bit sequences (~2048 bits) for robust error estimation"],
    ["Quantum Key Distribution", "QBER Security Threshold ($QBER_{th}$)", "11.00%", "[8.0%, 10.0%, 11.0%, 14.0%]", "Theoretical Shor-Preskill bound for unconditional security against collective attacks"],
    ["Quantum Key Distribution", "Error Testing Sample Fraction ($f_{test}$)", "0.20 (20%)", "[0.10, 0.15, 0.20, 0.25]", "Balances statistical confidence in QBER estimation against residual key throughput"],
    ["Quantum Key Distribution", "Sender State Polarization", "Equal Probability (p = 0.25 per state)", "[Uniform, Decoy-State Biased]", "Standard 4-state BB84 protocol: |0>, |1>, |+>, |->"],
    ["Quantum Key Distribution", "Receiver Measurement Basis", "Random Uniform Selection (p = 0.50)", "[p=0.50 Rectilinear, p=0.50 Diagonal]", "Ensures maximum entropy basis reconciliation for unbiased quantum eavesdropping detection"],

    # 3. Adaptive Key Management
    ["Adaptive Key Management", "Cascade Protocol Passes", "4 Passes", "[2, 3, 4, 5]", "Ensures complete elimination of odd and even multi-bit errors across all blocks"],
    ["Adaptive Key Management", "Initial Cascade Block Size ($k_1$)", "8 bits", "[4, 8, 16, 32]", "Optimized for initial low-to-moderate channel error rates (~2-5% QBER)"],
    ["Adaptive Key Management", "Subsequent Block Sizes ($k_2, k_3, k_4$)", "16, 32, 64 bits (Doubling Rule)", "[Static, Doubling, Logarithmic]", "Progressively doubles block dimensions to eliminate residual sparse parity errors"],
    ["Adaptive Key Management", "Universal Hashing Construction", "SHA-256 Cryptographic Compression", "[Toeplitz Matrix, Murmur3, SHA-256]", "Extracts uniform pseudo-random 256-bit keys with negligible collision probability"],
    ["Adaptive Key Management", "Key Authentication Verification", "HMAC-SHA256 (32 bits)", "[16 bits, 32 bits, 64 bits]", "Confirms 100% key reconciliation identity before cipher initialization"],
    ["Adaptive Key Management", "Key Renewal Usage Threshold", "10 image encryption operations", "[1, 5, 10, 25, 50]", "Enforces forward secrecy by retiring keys before statistical ciphertext leakage occurs"],
    ["Adaptive Key Management", "Key Lifespan Timeout", "3,600 seconds (1 hour)", "[600s, 1800s, 3600s]", "Invalidates stale key material in memory to mitigate cold-boot side-channel attacks"],

    # 4. Image Encryption (AES-256-GCM)
    ["Image Encryption", "Cipher Algorithm & Mode", "AES in Galois/Counter Mode (GCM)", "[AES-CBC, AES-CTR, AES-GCM, ChaCha20]", "Authenticated Encryption with Associated Data (AEAD) combining confidentiality with integrity"],
    ["Image Encryption", "Cipher Key Size", "256 bits (32 bytes)", "[128, 192, 256 bits]", "Maximum AES key strength providing post-quantum security against Grover search"],
    ["Image Encryption", "Cryptographic Nonce Length", "96 bits (12 bytes)", "[64, 96, 128 bits]", "NIST SP 800-38D recommended standard nonce size for optimal GHASH efficiency"],
    ["Image Encryption", "Integrity Authentication Tag Length", "128 bits (16 bytes)", "[64, 96, 128 bits]", "Maximum allowable GMAC tag length providing $2^{-128}$ forgery probability"],
    ["Image Encryption", "Differential Attack Plaintext Perturbation", "1 pixel inverted (LSB flip)", "[1 pixel, 5 pixels, 10 pixels]", "Standard NPCR/UACI differential cryptanalysis benchmark test condition"],

    # 5. Secure Medical Transmission (TLS)
    ["Secure Medical Transmission", "Network Protocol", "TLS 1.3 / TLS 1.2 over TCP", "[Plain TCP, TLS 1.2, TLS 1.3]", "Ensures secure cryptographic handshake and authenticated transport over PACS networks"],
    ["Secure Medical Transmission", "RSA Key Length", "2048 bits", "[1024, 2048, 4096 bits]", "NIST-compliant digital signature key length for gateway TLS certificate verification"],
    ["Secure Medical Transmission", "Digital Signature Algorithm", "SHA-256 with RSA Encryption", "[SHA-1, SHA-256, SHA-512]", "Cryptographically secure collision-resistant hashing for X.509 certificate validation"],
    ["Secure Medical Transmission", "Socket Streaming Buffer Size", "4,096 bytes", "[1024, 4096, 8192, 16384]", "Optimized TCP buffer size matching OS page size for efficient network streaming"],
    ["Secure Medical Transmission", "Socket Read/Write Timeout", "15.0 seconds", "[5.0s, 10.0s, 15.0s, 30.0s]", "Guards against socket deadlocks and hung client threads during network transfer"],

    # 6. Proposed Single-Conv DNN Architecture
    ["Proposed Single-Conv DNN", "Input Layer Dimensions", "224 x 224 x 3", "Fixed input shape", "Matches standard clinical image preprocessing tensor specification"],
    ["Proposed Single-Conv DNN", "Convolutional Layer Filters", "64 filters", "[16, 32, 64, 128]", "Provides rich multi-feature representation of tumor margins in a single conv layer"],
    ["Proposed Single-Conv DNN", "Convolutional Kernel Size", "7 x 7 pixels", "[3x3, 5x5, 7x7, 9x9]", "Broad receptive field capturing macro-lesion context and surrounding anatomical structures"],
    ["Proposed Single-Conv DNN", "Convolutional Stride", "2 pixels", "[1, 2, 4]", "Provides controlled $2\\times$ downsampling ($224 \\to 112$) preserving spatial localization"],
    ["Proposed Single-Conv DNN", "Convolutional Padding", "3 pixels (Same Padding)", "[0, 1, 2, 3]", "Preserves spatial boundary features without edge clipping artifacts"],
    ["Proposed Single-Conv DNN", "Convolutional Batch Normalization", "BatchNorm2d(64)", "[None, LayerNorm, BatchNorm2d]", "Accelerates convergence, stabilizes internal covariate shift, enables higher learning rate"],
    ["Proposed Single-Conv DNN", "Feature Activation Function", "Rectified Linear Unit (ReLU)", "[Sigmoid, Tanh, LeakyReLU, ReLU]", "Non-saturating non-linear activation accelerating gradient flow"],
    ["Proposed Single-Conv DNN", "Spatial Pooling Layer", "AdaptiveMaxPool2d((14, 14))", "[MaxPool(4,4), AvgPool, AdaptiveMaxPool(14,14)]", "Compresses $112 \\times 112$ feature map to $14 \\times 14$ while retaining peak tumor activations"],
    ["Proposed Single-Conv DNN", "Flattened Feature Dimension", "12,544 elements ($64 \\times 14 \\times 14$)", "Calculated from pool output", "Preserves fine localized spatial arrangements across cerebral lobes"],
    ["Proposed Single-Conv DNN", "Dense Hidden Layer Units", "512 neurons", "[128, 256, 512, 1024]", "High-capacity classification subspace separating the 4 complex brain tumor categories"],
    ["Proposed Single-Conv DNN", "Dense Batch Normalization", "BatchNorm1d(512)", "[None, LayerNorm, BatchNorm1d]", "Normalizes dense activations before non-linearity, stabilizing weight updates"],
    ["Proposed Single-Conv DNN", "Dropout Regularization Rate ($p$)", "0.40 (40% unit drop)", "[0.20, 0.30, 0.40, 0.50]", "Prevents co-adaptation of hidden features; eliminates overfitting on MRI backgrounds"],
    ["Proposed Single-Conv DNN", "Output Layer Units & Activation", "4 neurons (Softmax / Log-Softmax)", "4 distinct classes", "Generates calibrated posterior probabilities across Glioma, Meningioma, No Tumor, Pituitary"],

    # 7. Proposed DNN Training & Optimization
    ["Proposed DNN Training", "Loss Function", "Categorical Cross-Entropy Loss", "[Mean Squared Error, Focal Loss, Cross-Entropy]", "Standard probabilistic maximum likelihood loss for multi-class medical classification"],
    ["Proposed DNN Training", "Optimization Algorithm", "Adam (Adaptive Moment Estimation)", "[SGD with Momentum, RMSprop, Adam, AdamW]", "Combines AdaGrad and RMSProp advantages for fast convergence on sparse MRI features"],
    ["Proposed DNN Training", "Initial Learning Rate ($\\eta_0$)", "1.0 x 10^-3 ($0.001$)", "[1e-4, 5e-4, 1e-3, 2e-3]", "Optimal empirical learning rate providing stable monotonic loss reduction"],
    ["Proposed DNN Training", "Weight Decay ($L_2$ Regularization)", "1.0 x 10^-4 ($0.0001$)", "[0, 1e-5, 1e-4, 1e-3]", "Penalizes large convolutional and dense weight magnitudes, preventing weight explosion"],
    ["Proposed DNN Training", "Adam First Moment Decay ($\\beta_1$)", "0.90", "[0.85, 0.90, 0.95]", "Standard exponential decay rate for running gradient average"],
    ["Proposed DNN Training", "Adam Second Moment Decay ($\\beta_2$)", "0.999", "[0.99, 0.999, 0.9999]", "Standard exponential decay rate for running squared gradient average"],
    ["Proposed DNN Training", "Numerical Epsilon ($\\epsilon$)", "1.0 x 10^-8", "Fixed constant", "Prevents division by zero during adaptive parameter scaling"],
    ["Proposed DNN Training", "Learning Rate Scheduler", "CosineAnnealingLR", "[StepLR, ExponentialLR, ReduceLROnPlateau, CosineAnnealing]", "Smoothly decays learning rate from $10^{-3}$ down to $10^{-5}$ following half-cosine curve"],
    ["Proposed DNN Training", "Minimum Learning Rate ($\\eta_{min}$)", "1.0 x 10^-5 ($0.00001$)", "[1e-6, 1e-5, 1e-4]", "Floor learning rate enabling fine parameter tuning in late training epochs"],
    ["Proposed DNN Training", "Batch Size", "32 images", "[16, 32, 64, 128]", "Optimal mini-batch size balancing gradient variance against CPU cache locality"],
    ["Proposed DNN Training", "Maximum Training Epochs", "10 epochs", "[5, 10, 15, 20]", "Sufficient for complete training convergence (Train Acc 94.75%, Val Acc 92.76%)"],
    ["Proposed DNN Training", "Early Stopping Patience", "4 epochs without validation loss improvement", "[2, 3, 4, 5]", "Halts training if validation metrics plateau, preventing over-training"],
    ["Proposed DNN Training", "Best Model Checkpoint Rule", "Peak Validation Accuracy ($Val\\_Acc$)", "[Min Val Loss, Max Val Acc]", "Guarantees that the evaluated checkpoint represents the peak classification performance"],
    ["Proposed DNN Training", "Replication Random Seeds", "[42, 101, 2024]", "Independent seeds", "Ensures scientific reproducibility across independent dataset shuffles and initializations"],

    # 8. Baseline Models Configuration
    ["Baseline Models", "Conventional CNN - Architecture", "3 Convolutional Blocks (32, 64, 128) + 256 Dense", "Standard multi-layer CNN", "Standard baseline: Conv(3x3)+BN+ReLU+MaxPool(2,2) x3 -> Dense(256) -> Dropout(0.5) -> 4"],
    ["Baseline Models", "Conventional CNN - Optimizer & LR", "Adam (lr = 1.0 x 10^-3, weight_decay = 1e-4)", "Standard settings", "Trained from scratch under identical split and batch conditions (6 epochs)"],
    ["Baseline Models", "VGG16 - Pretrained Initialization", "ImageNet-1K Pretrained Weights (VGG16_Weights.DEFAULT)", "Transfer learning", "16-layer deep architecture featuring $3 \\times 3$ convolutional filters (134.3M params)"],
    ["Baseline Models", "VGG16 - Backbone Treatment", "Frozen Feature Extractor (requires_grad = False)", "[Full Fine-tuning, Frozen]", "Standard transfer learning head adaptation on CPU to benchmark feature transferability"],
    ["Baseline Models", "VGG16 - Modified Classifier Head", "Dropout(0.5) -> Linear(4096, 4)", "Custom 4-class head", "Replaces 1000-class ImageNet head with 4-class brain tumor classification layer"],
    ["Baseline Models", "VGG16 - Optimizer & LR", "Adam (lr = 1.0 x 10^-4, weight_decay = 1e-4)", "Fine-tuning rate", "Smaller learning rate appropriate for adapting pretrained transfer layers (3 epochs)"],
    ["Baseline Models", "ResNet50 - Pretrained Initialization", "ImageNet-1K Pretrained Weights (ResNet50_Weights.DEFAULT)", "Residual transfer", "50-layer deep residual network with bottleneck residual building blocks (23.5M params)"],
    ["Baseline Models", "ResNet50 - Backbone Treatment", "Frozen Residual Backbone (requires_grad = False)", "[Full Fine-tuning, Frozen]", "Preserves deep residual features while adapting final fully connected layer"],
    ["Baseline Models", "ResNet50 - Modified Classifier Head", "Dropout(0.4) -> Linear(2048, 4)", "Custom 4-class head", "Maps 2048-dim global average pooled residual vector to 4 tumor classes"],
    ["Baseline Models", "ResNet50 - Optimizer & LR", "Adam (lr = 1.0 x 10^-4, weight_decay = 1e-4)", "Fine-tuning rate", "Trained for 3 epochs under identical conditions"],
    ["Baseline Models", "MobileNetV2 - Pretrained Initialization", "ImageNet-1K Pretrained Weights (MobileNet_V2_Weights.DEFAULT)", "Lightweight baseline", "Lightweight mobile architecture with inverted residual blocks and linear bottlenecks (2.2M params)"],
    ["Baseline Models", "MobileNetV2 - Backbone Treatment", "Frozen Feature Backbone (requires_grad = False)", "[Full Fine-tuning, Frozen]", "Benchmarks lightweight mobile feature extractors against the proposed architecture"],
    ["Baseline Models", "MobileNetV2 - Modified Classifier Head", "Dropout(0.3) -> Linear(1280, 4)", "Custom 4-class head", "Maps 1280-dim feature vector to 4 tumor output classes"],
    ["Baseline Models", "MobileNetV2 - Optimizer & LR", "Adam (lr = 1.0 x 10^-4, weight_decay = 1e-4)", "Fine-tuning rate", "Trained for 4 epochs under identical data splits and preprocessing"]
]

# =============================================================================
# FORMATTING HELPER
# =============================================================================

def format_excel_sheet(ws, col_widths=None):
    """Applies high-grade corporate openpyxl formatting."""
    header_fill = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Calibri", size=10, bold=False)
    alt_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    
    thin_border = Border(
        left=Side(style="thin", color="D1D5DB"),
        right=Side(style="thin", color="D1D5DB"),
        top=Side(style="thin", color="D1D5DB"),
        bottom=Side(style="thin", color="D1D5DB")
    )
    
    # Format Header Row
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws.row_dimensions[1].height = 28
    
    # Format Data Rows
    for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=1, max_col=ws.max_column), start=2):
        ws.row_dimensions[row_idx].height = 22
        use_alt = (row_idx % 2 == 1)
        for cell in row:
            cell.font = data_font
            cell.border = thin_border
            if use_alt:
                cell.fill = alt_fill
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    
    # Set Column Widths
    if col_widths:
        for idx, width in enumerate(col_widths, start=1):
            col_letter = get_column_letter(idx)
            ws.column_dimensions[col_letter].width = width
    else:
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                v_str = str(cell.value or "")
                if len(v_str) > max_len:
                    max_len = len(v_str)
            ws.column_dimensions[col_letter].width = min(max(max_len + 4, 15), 55)

# =============================================================================
# WORKBOOK GENERATION
# =============================================================================

def update_master_workbook():
    master_path = "Adaptive_Quantum_Cryptography_DNN_Experimental_Results.xlsx"
    if not os.path.exists(master_path):
        print(f"Master workbook not found at {master_path}")
        return
        
    wb = openpyxl.load_workbook(master_path)
    
    # 1. Add / Replace 'System Configuration' Sheet
    if "System Configuration" in wb.sheetnames:
        del wb["System Configuration"]
    ws_sys = wb.create_sheet("System Configuration")
    for row in SYSTEM_CONFIG_DATA:
        ws_sys.append(row)
    format_excel_sheet(ws_sys, col_widths=[28, 38, 55, 65])
    print("Added 'System Configuration' sheet to master workbook.")
    
    # 2. Add / Replace 'Hyperparameters' Sheet
    if "Hyperparameters" in wb.sheetnames:
        del wb["Hyperparameters"]
    ws_hyp = wb.create_sheet("Hyperparameters")
    for row in HYPERPARAMETER_DATA:
        ws_hyp.append(row)
    format_excel_sheet(ws_hyp, col_widths=[28, 42, 35, 45, 65])
    print("Added 'Hyperparameters' sheet to master workbook.")
    
    wb.save(master_path)
    print(f"Master workbook successfully updated at: {master_path} (Now has {len(wb.sheetnames)} worksheets)")

def create_standalone_workbook():
    standalone_path = "System_Configuration_and_Hyperparameters.xlsx"
    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)
    
    # Sheet 1: System Configuration
    ws_sys = wb.create_sheet("System Configuration")
    for row in SYSTEM_CONFIG_DATA:
        ws_sys.append(row)
    format_excel_sheet(ws_sys, col_widths=[28, 38, 55, 65])
    
    # Sheet 2: Hyperparameters
    ws_hyp = wb.create_sheet("Hyperparameters")
    for row in HYPERPARAMETER_DATA:
        ws_hyp.append(row)
    format_excel_sheet(ws_hyp, col_widths=[28, 42, 35, 45, 65])
    
    wb.save(standalone_path)
    print(f"Standalone workbook successfully generated at: {standalone_path}")

if __name__ == "__main__":
    update_master_workbook()
    create_standalone_workbook()

