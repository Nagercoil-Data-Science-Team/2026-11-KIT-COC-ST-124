# Adaptive Quantum Cryptography and Deep Neural Network Framework for Secure Medical Image Transmission and Intelligent Disease Detection

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-ee4c2c.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## 1. Research Overview

This repository provides the official end-to-end Python implementation for the research paper:
> **"An Adaptive Quantum Cryptography and Deep Neural Network Framework for Secure Medical Image Transmission and Intelligent Disease Detection"**

The framework bridges a critical gap in medical IoT and e-Health: simultaneously securing medical image transmission via quantum-derived symmetric key cryptography and performing intelligent diagnostic classification with an ultra-lightweight Deep Neural Network (DNN).

### Key Architectural Pillars:
1. **Quantum Key Distribution (BB84 Protocol Simulation):**
   - Discrete-event simulation of quantum photon transmission across rectilinear and diagonal polarization bases.
   - Real-time Quantum Bit Error Rate (QBER) estimation with test-bit sampling.
2. **Adaptive Quantum Key Management:**
   - Adaptive security threshold ($QBER \le 11.0\%$) triggering automated key acceptance or rejection/revocation.
   - Interactive block parity error reconciliation (Cascade protocol).
   - Universal hashing and privacy amplification (HKDF/SHA-256 contraction) producing a verified 256-bit symmetric key.
3. **Authenticated Medical Image Encryption:**
   - AES-256-GCM authenticated encryption with cryptographically random 96-bit nonces.
   - Shannon entropy evaluation ($H(m) \approx 7.999x$).
   - Differential attack resilience (NPCR $> 99.60\%$, UACI $\approx 33.40\%$).
   - Negligible adjacent pixel correlation ($|r| \approx 0.00$).
4. **Secure Medical Image Transmission:**
   - Real-world socket-level Transport Layer Security (TLS) transmission.
   - Dynamic self-signed X.509 certificate generation.
   - Latency, throughput, packet delivery ratio (PDR), and communication overhead measurement.
5. **Image Authentication & Lossless Reconstitution:**
   - Receiver-side AES-GCM tag verification and deliberate 1-byte tamper detection (100% rejection).
   - Exact pixel-by-pixel lossless reconstruction ($MSE = 0.0, PSNR = \infty$).
6. **Intelligent Disease Detection (Proposed Single-Conv DNN):**
   - Lightweight single CNN convolutional feature extraction layer.
   - Max-pooling, dense fully connected layers with dropout (0.4) and batch normalization.
   - Four-class classification: **Glioma, Meningioma, Pituitary Tumor, No Tumor**.
7. **Comprehensive Baseline Comparisons:**
   - Benchmarked against Conventional CNN, VGG16, ResNet50, and MobileNetV2 under identical stratified splits and preprocessing.
   - Multi-seed statistical significance testing (paired t-test, Wilcoxon signed-rank test, Cohen's d effect sizes, 95% Confidence Intervals).

---

## 2. Directory Structure

```text
Adaptive_Quantum_DNN/
│
├── config.py                     # Centralized experiment parameters and directory paths
├── main.py                       # Single executable pipeline entry point
├── dataset_loader.py             # Dataset verification, duplicate hashing, and inventorying
├── preprocessing.py              # Denoising (Bilateral), CLAHE enhancement, and data augmentation
├── data_split.py                 # Stratified 70/15/15 dataset splitting with zero data leakage
├── bb84_quantum_key.py           # Simulated BB84 QKD protocol execution
├── adaptive_key_management.py    # QBER thresholding, Cascade error reconciliation & privacy amplification
├── aes_encryption.py             # AES-256-GCM encryption, entropy, NPCR, UACI & correlation analysis
├── secure_transmission.py        # TLS-protected socket transmission and network benchmarking
├── image_authentication.py       # Receiver authentication, tamper detection, and lossless reconstruction
├── proposed_dnn.py               # Proposed single-conv DNN architecture definition
├── baseline_models.py            # Conventional CNN, VGG16, ResNet50, MobileNetV2 definitions
├── model_training.py             # PyTorch training loop with early stopping and checkpointing
├── evaluation_metrics.py         # Multi-class confusion matrix, ROC-AUC, Precision, Recall, Specificity
├── statistical_analysis.py       # Mean, std, 95% CI, paired t-tests, Cohen's d effect sizes
├── visualization.py              # Publication-grade figures at 800 DPI (Times New Roman, bold styling)
├── excel_generation.py           # Master 11-sheet Excel workbook generator
├── experiment_logger.py          # Structured logging and JSON metrics serialization
│
├── checkpoints/                  # Saved optimal model weights (*.pth)
├── encrypted_images/             # Saved AES-256-GCM encrypted binary payloads
├── decrypted_images/             # Saved losslessly reconstructed PNG MRI images
├── results/
│   ├── plots/                    # 15 High-resolution 800 DPI PNG figures + vector PDFs
│   ├── tables/                   # Data splits and intermediate evaluation CSV tables
│   ├── logs/                     # Detailed execution logs
│   └── experiment_metrics/       # JSON file containing all raw experimental metrics
│
├── requirements.txt              # Pinned Python package dependencies
└── README.md                     # Comprehensive documentation
```

---

## 3. Dataset Collection & Preprocessing

The framework utilizes the original **Brain Tumor MRI Dataset** from Kaggle:
- **Classes:** Glioma, Meningioma, Pituitary Tumor, No Tumor
- **Total Images:** 7,200 (5,600 training set, 1,600 testing set)
- **Automatic Integrity Check:** Unreadable or corrupt images are automatically identified; SHA-256 hashing detects exact duplicate images across directories to ensure zero data leakage between splits.
- **Preprocessing Pipeline:**
  1. Image Resizing: $224 \times 224 \times 3$
  2. Noise Removal: Bilateral Filtering ($d=5, \sigma_{\text{color}}=50, \sigma_{\text{space}}=50$) to preserve tissue boundaries.
  3. Contrast Enhancement: Contrast Limited Adaptive Histogram Equalization (CLAHE, clip limit 2.0, grid size $8 \times 8$) in LAB color space.
  4. Augmentation (Training split only): Random horizontal flip ($p=0.5$), random rotation ($\pm 15^\circ$), random affine scaling ($0.85-1.0$), and color jitter ($0.15$).

---

## 4. Installation & Execution

### Prerequisites
- Python 3.10, 3.11, or 3.12+
- PyTorch and Torchvision
- CUDA-enabled GPU (optional; fully optimized for CPU execution)

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run Complete End-to-End Pipeline
Execute the master script to run the full workflow from data loading to 15 plots and 11-sheet Excel workbook generation:
```bash
python main.py
```

### Command Line Options
- `--epochs <N>`: Set number of training epochs for Proposed DNN (default: 10).
- `--sample_per_class <N>`: Number of training images per class for balanced CPU execution (default: 300).
- `--full_dataset`: Train on the complete 7,200 images without subsampling.

Example:
```bash
python main.py --epochs 10 --sample_per_class 300
```

---

## 5. Experimental Deliverables

### A. 15 Publication-Quality Plots (800 DPI + Vector PDF)
Saved in `Adaptive_Quantum_DNN/results/plots/`:
1. `01_training_validation_accuracy.png`
2. `02_training_validation_loss.png`
3. `03_confusion_matrix.png`
4. `04_classwise_metrics.png`
5. `05_multiclass_roc.png`
6. `06_sample_predictions.png`
7. `07_encrypted_images.png`
8. `08_decrypted_images.png`
9. `09_original_encrypted_comparison.png`
10. `10_encryption_decryption_time.png`
11. `11_quantum_key_generation.png`
12. `12_statistical_security_analysis.png`
13. `13_overall_performance_comparison.png`
14. `14_secure_transmission_performance.png`
15. `15_adaptive_key_management.png`

### B. Master Excel Workbook (11 Worksheets)
File: `Adaptive_Quantum_Cryptography_DNN_Experimental_Results.xlsx`
- **Sheet 1:** Dataset Distribution
- **Sheet 2:** Quantum Key Generation
- **Sheet 3:** Adaptive Quantum Key Management
- **Sheet 4:** Medical Image Encryption and Decryption
- **Sheet 5:** Statistical Security Analysis
- **Sheet 6:** Secure Medical Image Transmission
- **Sheet 7:** Image Authentication and Integrity Verification
- **Sheet 8:** Proposed DNN Classification
- **Sheet 9:** Class-wise Classification Metrics
- **Sheet 10:** Comparative Analysis
- **Sheet 11:** Overall Performance Evaluation

---

## 6. Research Integrity & Reproducibility Statement

All metrics, encryption benchmarks, transmission measurements, and neural network evaluations reported in this project are strictly calculated from live experimental execution on real Brain Tumor MRI data. No metrics are fabricated, hardcoded, or artificially interpolated.

