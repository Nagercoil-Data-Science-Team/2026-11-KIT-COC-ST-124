"""
Generate 3 image samples showing Original vs Preprocessed MRI images:
- Sample 1: Glioma
- Sample 2: Meningioma
- Sample 3: Pituitary Tumor

Saves:
1. High-resolution comparison figure: original_vs_preprocessed_comparison.png (800 DPI)
2. Individual PNG files for each original and preprocessed sample
3. Copies to both workspace and artifact directories for direct inspection
"""

import os
import cv2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Paths
WORKSPACE_ROOT = r"d:\Alan christo\November2026\2026-11-KIT-COC-ST-124"
OUT_DIR_WS = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "preprocessing_samples")
ARTIFACT_DIR = r"C:\Users\ADMIN\.gemini\antigravity\brain\16b69d4e-28c0-4e70-a31b-40ad038119a4"
OUT_DIR_ART = os.path.join(ARTIFACT_DIR, "preprocessing_samples")

os.makedirs(OUT_DIR_WS, exist_ok=True)
os.makedirs(OUT_DIR_ART, exist_ok=True)

# Import preprocessing pipeline
import sys
sys.path.append(os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN"))
from preprocessing import preprocess_mri_image

MANIFEST_PATH = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "tables", "data_splits_manifest.csv")
df = pd.read_csv(MANIFEST_PATH)

# Select 3 clear representative samples from 3 distinct classes
selected_samples_info = [
    {
        "id": "Sample_01",
        "class": "Glioma",
        "label": "Sample 1: Glioma",
        "description": "Infiltrative frontoparietal mass lesion with surrounding perifocal vasogenic edema"
    },
    {
        "id": "Sample_02",
        "class": "Meningioma",
        "label": "Sample 2: Meningioma",
        "description": "Well-circumscribed extra-axial dural-based mass compressing adjacent cortical cortex"
    },
    {
        "id": "Sample_03",
        "class": "Pituitary Tumor",
        "label": "Sample 3: Pituitary Tumor",
        "description": "Focal round macroadenoma centered in the sella turcica with suprasellar expansion"
    }
]

# Locate clear non-augmented filepaths from manifest
for item in selected_samples_info:
    c_df = df[(df["class_name"] == item["class"]) & (~df["filepath"].str.contains("aug", case=False))]
    if len(c_df) == 0:
        c_df = df[df["class_name"] == item["class"]]
    item["filepath"] = c_df.iloc[len(c_df) // 3]["filepath"]

# Process and save individual images
processed_records = []
for item in selected_samples_info:
    prep = preprocess_mri_image(item["filepath"], apply_enhancement=True)
    orig_rgb = prep["resized_original"]
    prep_rgb = prep["preprocessed_uint8"]
    
    # Save individual PNGs
    base_name = f"{item['id'].lower()}_{item['class'].lower().replace(' ', '_')}"
    
    orig_ws = os.path.join(OUT_DIR_WS, f"{base_name}_original.png")
    orig_art = os.path.join(OUT_DIR_ART, f"{base_name}_original.png")
    prep_ws = os.path.join(OUT_DIR_WS, f"{base_name}_preprocessed.png")
    prep_art = os.path.join(OUT_DIR_ART, f"{base_name}_preprocessed.png")
    
    plt.imsave(orig_ws, orig_rgb)
    plt.imsave(orig_art, orig_rgb)
    plt.imsave(prep_ws, prep_rgb)
    plt.imsave(prep_art, prep_rgb)
    
    item["orig_ws"] = orig_ws
    item["prep_ws"] = prep_ws
    item["orig_art"] = orig_art
    item["prep_art"] = prep_art
    item["orig_rgb"] = orig_rgb
    item["prep_rgb"] = prep_rgb

# Generate clean publication-grade 3x2 side-by-side comparison figure
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"

fig, axes = plt.subplots(3, 2, figsize=(11, 14))

stages = ["Original Image", "Preprocessed Image (Denoised + CLAHE)"]

for r_idx, item in enumerate(selected_samples_info):
    # Column 0: Original
    ax_orig = axes[r_idx, 0]
    ax_orig.imshow(item["orig_rgb"])
    ax_orig.axis("off")
    ax_orig.set_title(f"{item['label']} (Original)", fontsize=14, fontweight="bold", pad=8)
    
    # Column 1: Preprocessed
    ax_prep = axes[r_idx, 1]
    ax_prep.imshow(item["prep_rgb"])
    ax_prep.axis("off")
    ax_prep.set_title(f"{item['label']} (Preprocessed)", fontsize=14, fontweight="bold", pad=8)

fig.suptitle("Comparison of Original and Preprocessed Brain MRI Images", fontsize=18, fontweight="bold", y=0.99)
plt.tight_layout()

cmp_ws = os.path.join(OUT_DIR_WS, "original_vs_preprocessed_comparison.png")
cmp_art = os.path.join(OUT_DIR_ART, "original_vs_preprocessed_comparison.png")

fig.savefig(cmp_ws, dpi=800, bbox_inches="tight")
fig.savefig(cmp_art, dpi=800, bbox_inches="tight")
plt.close(fig)

print("Generated comparison figure successfully:")
print("  - Workspace:", cmp_ws)
print("  - Artifact:", cmp_art)
for item in selected_samples_info:
    print(f"  {item['label']}:")
    print(f"    Original: {item['orig_ws']}")
    print(f"    Preprocessed: {item['prep_ws']}")

