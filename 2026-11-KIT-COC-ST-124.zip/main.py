"""
Single Executable Entry Point for Adaptive Quantum Cryptography and DNN Framework
"""

import sys
import os

# Set path to Adaptive_Quantum_DNN directory
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
MODULE_DIR = os.path.join(CURRENT_DIR, "Adaptive_Quantum_DNN")
if MODULE_DIR not in sys.path:
    sys.path.insert(0, MODULE_DIR)

from main import run_framework_pipeline
import argparse
from config import DEFAULT_EPOCHS

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Adaptive Quantum Cryptography & DNN Framework for Medical Image Security and Disease Detection"
    )
    parser.add_argument(
        "--epochs", type=int, default=DEFAULT_EPOCHS,
        help="Number of epochs for Proposed DNN training (default: 10)"
    )
    parser.add_argument(
        "--sample_per_class", type=int, default=800,
        help="Training images per class for balanced execution (default: 800)"
    )
    parser.add_argument(
        "--full_dataset", action="store_true",
        help="Use entire dataset (5600 train, 1600 test) without subsampling"
    )
    
    args = parser.parse_args()
    run_framework_pipeline(args)

