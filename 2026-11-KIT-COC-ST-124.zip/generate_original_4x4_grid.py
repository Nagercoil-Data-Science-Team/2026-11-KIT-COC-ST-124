"""
Generate pure original brain MRI image samples in 4x4 layout (16 samples)
and 8-sample layout:
- Row 1: Glioma (4 original clinical samples)
- Row 2: Meningioma (4 original clinical samples)
- Row 3: No Tumor (4 original clinical samples)
- Row 4: Pituitary Tumor (4 original clinical samples)

All images are pure original clinical MRI scans from the dataset.
Rendered at 800 DPI with publication-standard Times New Roman bold styling.
"""

import os
import cv2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Paths
WORKSPACE_ROOT = r"d:\Alan christo\November2026\2026-11-KIT-COC-ST-124"
PLOTS_DIR = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "plots")
SAMPLES_DIR = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "class_samples")
ARTIFACT_DIR = r"C:\Users\ADMIN\.gemini\antigravity\brain\16b69d4e-28c0-4e70-a31b-40ad038119a4"

os.makedirs(PLOTS_DIR, exist_ok=True)
os.makedirs(SAMPLES_DIR, exist_ok=True)
os.makedirs(ARTIFACT_DIR, exist_ok=True)

MANIFEST_PATH = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "tables", "data_splits_manifest.csv")
df = pd.read_csv(MANIFEST_PATH)

CLASSES = ["Glioma", "Meningioma", "No Tumor", "Pituitary Tumor"]

# Pick 4 clear, non-augmented original scans per class (total 16 for 4x4 grid)
samples_dict = {}
for c in CLASSES:
    c_df = df[(df["class_name"] == c) & (~df["filepath"].str.contains("aug", case=False))]
    if len(c_df) < 4:
        c_df = df[df["class_name"] == c]
    # Pick 4 well-spaced representative samples
    indices = np.linspace(10, len(c_df) - 10, 4, dtype=int)
    samples_dict[c] = c_df.iloc[indices]["filepath"].tolist()

# Apply publication style
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"
plt.rcParams["axes.labelweight"] = "bold"
plt.rcParams["axes.titleweight"] = "bold"
plt.rcParams["figure.titleweight"] = "bold"

# =============================================================================
# 1. 4x4 LAYOUT (16 ORIGINAL IMAGES: 4 CLASSES x 4 SAMPLES)
# =============================================================================
fig_4x4, axes_4x4 = plt.subplots(4, 4, figsize=(16, 16.5))

for r_idx, c in enumerate(CLASSES):
    for c_idx in range(4):
        fpath = samples_dict[c][c_idx]
        bgr = cv2.imread(fpath)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        resized = cv2.resize(rgb, (224, 224), interpolation=cv2.INTER_AREA)
        
        ax = axes_4x4[r_idx, c_idx]
        ax.imshow(resized)
        ax.axis("off")
        ax.grid(False)
        
        # Subplot title
        ax.set_title(f"{c} - Sample {c_idx + 1}", fontsize=14, fontweight="bold", pad=8)
        
        # Add prominent class label on the far left of each row
        if c_idx == 0:
            ax.text(-0.12, 0.5, c, transform=ax.transAxes,
                    fontsize=18, fontweight="bold", va="center", ha="right", rotation=90)

fig_4x4.suptitle("Original Brain Tumor MRI Image Samples", fontsize=22, fontweight="bold", y=0.99)
plt.tight_layout()

out_4x4_plots = os.path.join(PLOTS_DIR, "original_samples_4x4_layout.png")
out_4x4_samples = os.path.join(SAMPLES_DIR, "original_samples_4x4_layout.png")
out_4x4_artifact = os.path.join(ARTIFACT_DIR, "original_samples_4x4_layout.png")

fig_4x4.savefig(out_4x4_plots, dpi=800, bbox_inches="tight")
fig_4x4.savefig(out_4x4_samples, dpi=800, bbox_inches="tight")
fig_4x4.savefig(out_4x4_artifact, dpi=800, bbox_inches="tight")
plt.close(fig_4x4)
print(f"4x4 Layout saved successfully at 800 DPI to:\n  - {out_4x4_plots}\n  - {out_4x4_artifact}")

# =============================================================================
# 2. 8-IMAGE LAYOUT (2x4 / 4x2: 2 ORIGINAL SAMPLES PER CLASS)
# =============================================================================
# In case '8' refers to 8 images (2 per class) in a 4-row x 2-col or 2-row x 4-col layout
fig_8, axes_8 = plt.subplots(4, 2, figsize=(10, 16))

for r_idx, c in enumerate(CLASSES):
    for c_idx in range(2):
        fpath = samples_dict[c][c_idx]
        bgr = cv2.imread(fpath)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        resized = cv2.resize(rgb, (224, 224), interpolation=cv2.INTER_AREA)
        
        ax = axes_8[r_idx, c_idx]
        ax.imshow(resized)
        ax.axis("off")
        ax.grid(False)
        ax.set_title(f"{c} - Sample {c_idx + 1}", fontsize=14, fontweight="bold", pad=8)
        
        if c_idx == 0:
            ax.text(-0.15, 0.5, c, transform=ax.transAxes,
                    fontsize=16, fontweight="bold", va="center", ha="right", rotation=90)

fig_8.suptitle("Original Brain Tumor MRI Image Samples (8 Samples)", fontsize=20, fontweight="bold", y=0.99)
plt.tight_layout()

out_8_plots = os.path.join(PLOTS_DIR, "original_samples_8_layout.png")
out_8_artifact = os.path.join(ARTIFACT_DIR, "original_samples_8_layout.png")

fig_8.savefig(out_8_plots, dpi=800, bbox_inches="tight")
fig_8.savefig(out_8_artifact, dpi=800, bbox_inches="tight")
plt.close(fig_8)
print(f"8-Image Layout saved successfully at 800 DPI to:\n  - {out_8_plots}\n  - {out_8_artifact}")

