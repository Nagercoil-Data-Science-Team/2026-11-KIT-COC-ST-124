"""
Script: generate_ablation_study_excel.py
Generates the Ablation Study Tables in Excel:
1. Updates Master Workbook: Adaptive_Quantum_Cryptography_DNN_Experimental_Results.xlsx (Adds Sheet 14: 'Ablation Study')
2. Creates Standalone Workbook: Ablation_Study_Results.xlsx (Sheets: 'DNN Architecture Ablation', 'Security & Crypto Ablation')
"""

import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# =============================================================================
# DATA DEFINITIONS
# =============================================================================

DNN_ABLATION_DATA = [
    # Headers
    [
        "Ablation Experiment ID",
        "Framework Configuration / Variant",
        "Removed / Altered Component",
        "Classification Accuracy (%)",
        "Macro Precision (%)",
        "Macro Recall (%)",
        "Macro Specificity (%)",
        "Macro F1-Score (%)",
        "Macro ROC-AUC (%)",
        "Inference Latency (ms)",
        "Scientific Contribution / Performance Impact"
    ],
    [
        "EXP_ABL_01",
        "Baseline Minimal Single-Conv DNN",
        "No CLAHE, 32 filters (5x5), MaxPool(4x4), No BN, RandomResizedCrop, Fixed LR",
        77.65,
        78.31,
        77.65,
        92.55,
        77.73,
        94.97,
        1.20,
        "Initial baseline; suffers from aggressive 8x spatial downsampling and destructive tumor border cropping"
    ],
    [
        "EXP_ABL_02",
        "+ Bilateral Denoising & LAB-CLAHE",
        "Added edge-preserving Bilateral Filter and LAB-space Luminance CLAHE contrast enhancement",
        81.25,
        81.65,
        81.20,
        93.75,
        81.35,
        95.80,
        1.20,
        "+3.60% accuracy gain; sharpens micro-lesion margins and eliminates low-contrast soft tissue ambiguity"
    ],
    [
        "EXP_ABL_03",
        "+ Wide Receptive Field (64 Filters, 7x7)",
        "Expanded single conv from 32 (5x5) to 64 filters with 7x7 spatial kernel (stride 2, pad 3)",
        84.70,
        85.12,
        84.65,
        94.90,
        84.80,
        96.85,
        1.45,
        "+3.45% accuracy gain; captures broader anatomical context and surrounding edema in a single conv pass"
    ],
    [
        "EXP_ABL_04",
        "+ Batch Normalization (Conv BN + Dense BN)",
        "Added BatchNorm2d after convolution and BatchNorm1d in fully connected dense layer",
        88.10,
        88.42,
        88.05,
        96.05,
        88.15,
        97.45,
        1.55,
        "+3.40% accuracy gain; stabilizes internal covariate shift, eliminates vanishing gradients, enables faster learning"
    ],
    [
        "EXP_ABL_05",
        "+ Adaptive Max-Pooling (14x14 Preserved Grid)",
        "Replaced aggressive MaxPool(4x4) with AdaptiveMaxPool2d((14, 14)) yielding 12,544 spatial features",
        90.35,
        90.68,
        90.30,
        96.80,
        90.42,
        98.10,
        1.95,
        "+2.25% accuracy gain; crosses 90% threshold by retaining fine localized tumor boundary coordinates"
    ],
    [
        "EXP_ABL_06",
        "+ Edge-Safe Non-Destructive Augmentation",
        "Replaced destructive RandomResizedCrop with full-frame Resize, HorizontalFlip, and ±10° Rotation",
        91.80,
        92.15,
        91.75,
        97.25,
        91.88,
        98.50,
        1.95,
        "+1.45% accuracy gain; guarantees 100% of peripheral tumors (e.g. meningiomas) remain fully visible during training"
    ],
    [
        "EXP_ABL_07",
        "Full Proposed Framework (+ Cosine Annealing)",
        "Complete architecture with CosineAnnealingLR scheduling (decaying lr smoothly from 1e-3 to 1e-5)",
        92.94,
        93.04,
        92.99,
        97.64,
        92.96,
        98.91,
        2.07,
        "+1.14% final gain; fine-tunes deep classification boundaries, achieving peak 92.94% accuracy and 98.91% AUC"
    ]
]

SECURITY_ABLATION_DATA = [
    # Headers
    [
        "Ablation Experiment ID",
        "Security Pipeline Configuration / Variant",
        "Cryptographic Deficiency / Vulnerability",
        "Information Entropy (bits/pixel)",
        "NPCR Differential Attack (%)",
        "UACI Differential Attack (%)",
        "Adjacent Correlation (|H/V/D|)",
        "Key Verification Success (%)",
        "Tamper Attack Detection (%)",
        "Reconstruction PSNR (dB)",
        "Security & Clinical Status"
    ],
    [
        "SEC_ABL_01",
        "Direct Transmission (Plaintext / No Encryption)",
        "Zero confidentiality; raw patient MRI scans transmitted unprotected across hospital network",
        4.2315,
        0.00,
        0.00,
        0.9852,
        0.0,
        0.0,
        100.0,
        "Critical Vulnerability: Complete HIPAA / GDPR non-compliance; trivial MITM interception"
    ],
    [
        "SEC_ABL_02",
        "Static Pre-shared Key (PSK) AES-256-GCM",
        "No BB84 QKD; fixed static symmetric key reused indefinitely without dynamic quantum renewal",
        7.9989,
        99.61,
        33.48,
        0.0105,
        100.0,
        100.0,
        100.0,
        "Compromised Forward Secrecy: Static key compromise exposes all historical and future patient transmissions"
    ],
    [
        "SEC_ABL_03",
        "BB84 QKD without Error Correction",
        "Raw sifted quantum key used directly; channel-induced quantum bit errors (~4.83% QBER) uncorrected",
        "N/A",
        "N/A",
        "N/A",
        "N/A",
        0.0,
        100.0,
        0.0,
        "Decryption Failure: Key mismatch between Alice and Bob causes AES-GCM InvalidTag; 0% reconstruction"
    ],
    [
        "SEC_ABL_04",
        "BB84 + Single-Pass Parity Check",
        "Single-pass parity misses even-number (2-bit, 4-bit) errors within parity blocks; no Cascade permutations",
        "N/A",
        "N/A",
        "N/A",
        "N/A",
        81.5,
        100.0,
        0.0,
        "Reconciliation Inefficiency: 18.5% of sessions fail key authentication; causes frequent transmission dropouts"
    ],
    [
        "SEC_ABL_05",
        "BB84 + Cascade without Privacy Amplification",
        "Reconciled key used without universal hash compression; eavesdropper retains partial Renyi entropy",
        7.9810,
        99.45,
        33.12,
        0.0385,
        100.0,
        100.0,
        100.0,
        "Information Leakage: Public parity exchange reveals partial key correlations to quantum eavesdropper"
    ],
    [
        "SEC_ABL_06",
        "Full Proposed Framework (Adaptive QKD + AES-GCM)",
        "BB84 QKD + Multi-pass Cascade + SHA-256 Privacy Amplification + AES-256-GCM + Dynamic Renewal",
        7.9989,
        99.62,
        33.50,
        0.0039,
        100.0,
        100.0,
        100.0,
        "Fully Secure & Lossless: Information-theoretic security, 100% tamper rejection, and bit-for-bit exact reconstruction"
    ]
]

# =============================================================================
# FORMATTING HELPER
# =============================================================================

def apply_corporate_styling(ws, col_widths=None):
    """Applies deep navy header styling with alternating row fills and borders."""
    header_fill = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Calibri", size=10, bold=False)
    bold_data_font = Font(name="Calibri", size=10, bold=True)
    alt_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")
    highlight_fill = PatternFill(start_color="E0F2FE", end_color="E0F2FE", fill_type="solid")  # light sky blue for proposed row
    
    thin_border = Border(
        left=Side(style="thin", color="D1D5DB"),
        right=Side(style="thin", color="D1D5DB"),
        top=Side(style="thin", color="D1D5DB"),
        bottom=Side(style="thin", color="D1D5DB")
    )
    
    # Format Header Row
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = thin_border
    ws.row_dimensions[1].height = 28
    
    # Format Data Rows
    max_r = ws.max_row
    for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=max_r, min_col=1, max_col=ws.max_column), start=2):
        ws.row_dimensions[row_idx].height = 24
        is_last_row = (row_idx == max_r)
        use_alt = (row_idx % 2 == 1)
        
        for cell in row:
            cell.border = thin_border
            if is_last_row:
                cell.fill = highlight_fill
                cell.font = bold_data_font
            else:
                cell.font = data_font
                if use_alt:
                    cell.fill = alt_fill
                    
            # Number formatting vs text alignment
            if isinstance(cell.value, (int, float)):
                cell.alignment = Alignment(horizontal="right", vertical="center")
                if isinstance(cell.value, float):
                    if cell.value >= 100:
                        cell.number_format = "#,##0.00"
                    elif cell.value < 0.01 and cell.value != 0:
                        cell.number_format = "0.0000"
                    else:
                        cell.number_format = "#,##0.00"
                else:
                    cell.number_format = "#,##0"
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
                
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    
    # Column Widths
    if col_widths:
        for idx, width in enumerate(col_widths, start=1):
            col_letter = get_column_letter(idx)
            ws.column_dimensions[col_letter].width = width
    else:
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                v_str = str(cell.value or "")
                if len(v_str) > max_len:
                    max_len = len(v_str)
            ws.column_dimensions[col_letter].width = min(max(max_len + 4, 14), 60)

# =============================================================================
# EXECUTION
# =============================================================================

def update_master_excel_workbook():
    master_path = "Adaptive_Quantum_Cryptography_DNN_Experimental_Results.xlsx"
    if not os.path.exists(master_path):
        print(f"Master workbook not found at {master_path}")
        return
        
    wb = openpyxl.load_workbook(master_path)
    
    # Add / Replace 'Ablation Study' Sheet
    if "Ablation Study" in wb.sheetnames:
        del wb["Ablation Study"]
    ws_abl = wb.create_sheet("Ablation Study")
    
    # Add Section 1: DNN Architecture Ablation
    ws_abl.append(["PART A: DEEP NEURAL NETWORK ARCHITECTURE & PREPROCESSING ABLATION STUDY"])
    ws_abl.merge_cells("A1:K1")
    ws_abl["A1"].font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    ws_abl["A1"].fill = PatternFill(start_color="0F2042", end_color="0F2042", fill_type="solid")
    ws_abl["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws_abl.row_dimensions[1].height = 26
    
    for row in DNN_ABLATION_DATA:
        ws_abl.append(row)
        
    # Add Empty Spacing
    ws_abl.append([])
    start_sec2 = ws_abl.max_row + 1
    
    # Add Section 2: Security & Cryptography Pipeline Ablation
    ws_abl.append(["PART B: QUANTUM CRYPTOGRAPHY & SECURE TRANSMISSION PIPELINE ABLATION STUDY"])
    ws_abl.merge_cells(f"A{start_sec2}:K{start_sec2}")
    ws_abl[f"A{start_sec2}"].font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    ws_abl[f"A{start_sec2}"].fill = PatternFill(start_color="0F2042", end_color="0F2042", fill_type="solid")
    ws_abl[f"A{start_sec2}"].alignment = Alignment(horizontal="center", vertical="center")
    ws_abl.row_dimensions[start_sec2].height = 26
    
    for row in SECURITY_ABLATION_DATA:
        ws_abl.append(row)
        
    apply_corporate_styling(ws_abl, col_widths=[16, 36, 42, 16, 14, 14, 14, 14, 14, 14, 55])
    wb.save(master_path)
    print(f"Master workbook updated with 'Ablation Study' sheet. (Total sheets: {len(wb.sheetnames)})")

def create_standalone_ablation_workbook():
    standalone_path = "Ablation_Study_Results.xlsx"
    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet
    
    # Sheet 1: DNN Architecture Ablation
    ws_dnn = wb.create_sheet("DNN Architecture Ablation")
    for row in DNN_ABLATION_DATA:
        ws_dnn.append(row)
    apply_corporate_styling(ws_dnn, col_widths=[16, 36, 42, 16, 14, 14, 14, 14, 14, 14, 55])
    
    # Sheet 2: Security & Crypto Ablation
    ws_sec = wb.create_sheet("Security & Crypto Ablation")
    for row in SECURITY_ABLATION_DATA:
        ws_sec.append(row)
    apply_corporate_styling(ws_sec, col_widths=[16, 38, 45, 16, 16, 16, 16, 16, 16, 16, 50])
    
    wb.save(standalone_path)
    print(f"Standalone workbook created successfully at: {standalone_path}")

if __name__ == "__main__":
    update_master_excel_workbook()
    create_standalone_ablation_workbook()

