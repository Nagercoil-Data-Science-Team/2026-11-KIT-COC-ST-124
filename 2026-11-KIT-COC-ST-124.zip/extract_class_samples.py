"""
Extract representative brain tumor MRI image samples for all four classes:
- Glioma
- Meningioma
- No Tumor
- Pituitary Tumor

Generates:
1. High-resolution 4x4 comparison grid figure (800 DPI)
2. Individual PNG samples organized by class
3. Copies to both workspace results folder and brain artifact folder for visual presentation
"""

import os
import shutil
import cv2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Paths
WORKSPACE_ROOT = r"d:\Alan christo\November2026\2026-11-KIT-COC-ST-124"
RESULTS_DIR = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "class_samples")
ARTIFACT_DIR = r"C:\Users\ADMIN\.gemini\antigravity\brain\16b69d4e-28c0-4e70-a31b-40ad038119a4"
ARTIFACT_SAMPLES_DIR = os.path.join(ARTIFACT_DIR, "class_samples")

os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(ARTIFACT_SAMPLES_DIR, exist_ok=True)

MANIFEST_PATH = os.path.join(WORKSPACE_ROOT, "Adaptive_Quantum_DNN", "results", "tables", "data_splits_manifest.csv")
df = pd.read_csv(MANIFEST_PATH)

CLASSES = ["Glioma", "Meningioma", "No Tumor", "Pituitary Tumor"]
CLASS_DETAILS = {
    "Glioma": {
        "description": "Infiltrative intra-axial tumor originating from glial cells within cerebral hemispheres",
        "features": "Irregular boundaries, mass effect, surrounding perifocal vasogenic edema"
    },
    "Meningioma": {
        "description": "Extra-axial tumor arising from the arachnoid cap cells of meninges",
        "features": "Dural tail sign, distinct well-circumscribed margins abutting skull or falx"
    },
    "No Tumor": {
        "description": "Healthy, normal brain MRI scan with no neoplastic lesions or mass effect",
        "features": "Preserved bilateral symmetry, normal ventricular system, distinct grey/white matter"
    },
    "Pituitary Tumor": {
        "description": "Neuroendocrine neoplasm situated in the sella turcica at the skull base",
        "features": "Sellar/suprasellar expansion, compression of the optic chiasm, discrete adenoma"
    }
}

# Collect 4 distinct representative samples per class
samples_per_class = {}
for c in CLASSES:
    # Prefer original non-augmented images where possible
    c_df = df[df["class_name"] == c]
    # Filter for clear non-augmented training/testing filenames
    orig_samples = c_df[~c_df["filepath"].str.contains("aug", case=False)]
    if len(orig_samples) < 4:
        orig_samples = c_df
    
    # Pick 4 evenly spaced samples across the set for morphological diversity
    indices = np.linspace(0, len(orig_samples) - 1, 4, dtype=int)
    picked = orig_samples.iloc[indices]["filepath"].tolist()
    samples_per_class[c] = picked

# Save individual images and copy
extracted_summary = []
for c in CLASSES:
    c_folder_ws = os.path.join(RESULTS_DIR, c.replace(" ", "_"))
    c_folder_art = os.path.join(ARTIFACT_SAMPLES_DIR, c.replace(" ", "_"))
    os.makedirs(c_folder_ws, exist_ok=True)
    os.makedirs(c_folder_art, exist_ok=True)
    
    for idx, fpath in enumerate(samples_per_class[c], start=1):
        img_bgr = cv2.imread(fpath)
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        resized = cv2.resize(img_rgb, (224, 224), interpolation=cv2.INTER_AREA)
        
        filename = f"{c.lower().replace(' ', '_')}_sample_{idx}.png"
        ws_out = os.path.join(c_folder_ws, filename)
        art_out = os.path.join(c_folder_art, filename)
        
        # Save RGB image
        plt.imsave(ws_out, resized)
        plt.imsave(art_out, resized)
        
        extracted_summary.append({
            "Class Name": c,
            "Sample ID": f"Sample {idx}",
            "Original Path": fpath,
            "Workspace Saved Path": ws_out,
            "Artifact Path": art_out
        })

# Generate 4x4 publication-quality comparison figure
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["font.weight"] = "bold"

fig, axes = plt.subplots(4, 4, figsize=(16, 16))

for r_idx, c in enumerate(CLASSES):
    for c_idx in range(4):
        fpath = samples_per_class[c][c_idx]
        img = cv2.cvtColor(cv2.imread(fpath), cv2.COLOR_BGR2RGB)
        img_res = cv2.resize(img, (224, 224), interpolation=cv2.INTER_AREA)
        
        ax = axes[r_idx, c_idx]
        ax.imshow(img_res)
        ax.axis("off")
        
        if c_idx == 0:
            ax.set_ylabel(c, fontsize=16, fontweight="bold", labelpad=15)
            # Add row title on the left
            ax.text(-0.15, 0.5, c, transform=ax.transAxes,
                    fontsize=18, fontweight="bold", va="center", ha="right", rotation=90)
            
        ax.set_title(f"{c} - Sample {c_idx + 1}", fontsize=14, fontweight="bold", pad=8)

fig.suptitle("Brain Tumor MRI Representative Class Samples",
             fontsize=22, fontweight="bold", y=0.99)
plt.tight_layout()

grid_ws = os.path.join(RESULTS_DIR, "brain_tumor_class_samples_grid.png")
grid_art = os.path.join(ARTIFACT_SAMPLES_DIR, "brain_tumor_class_samples_grid.png")

fig.savefig(grid_ws, dpi=400, bbox_inches="tight")
fig.savefig(grid_art, dpi=400, bbox_inches="tight")
plt.close(fig)

print(f"Grid figure saved to:\n  - {grid_ws}\n  - {grid_art}")
print(f"Total extracted individual samples: {len(extracted_summary)}")

